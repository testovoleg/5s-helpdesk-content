@cd /d "%~dp0"
PbfProxy --uninstall
pause

