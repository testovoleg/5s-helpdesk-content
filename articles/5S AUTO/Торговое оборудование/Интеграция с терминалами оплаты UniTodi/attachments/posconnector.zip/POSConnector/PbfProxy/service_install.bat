@cd /d "%~dp0"
PbfProxy --install
PbfProxy --start
pause

