@echo off
setlocal ENABLEDELAYEDEXPANSION
@cd /d "%~dp0"
wmic path Win32_SerialPort get DeviceID | findstr /V "DeviceID" > tmptest.txt
rm port_list.txt
for /f "usebackq delims=" %%i in ("tmptest.txt") do (
    for /f "usebackq delims=" %%j in ('%%i') do (
        set str=%%j
        for /l %%a in (1,1,31) do if "!str:~-1!"==" " set str=!str:~0,-1!
        echo !str!
    ) >> port_list.txt
)
rm tmptest.txt