@echo off
set "oldpath=%cd%"
cd /d "%WinDir%\winsxs"
dir /S /B "PnPutil.exe"
FOR /F "tokens=*" %%I IN ('dir /S /B "PnPutil.exe"') DO SET var=%%I
cd /d "%oldpath%"
"%var%" -i -a Vanstone_USB2UART.inf
pause